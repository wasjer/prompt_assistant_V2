/**
 * AI Prompt 捕获脚本（多平台适配器模式）
 * 职责：监听用户输入，提取 prompt 并发送给后台脚本
 * 使用实时缓存策略：在用户输入时实时缓存内容，避免 DOM 清空导致丢失
 * 支持平台：ChatGPT, 通义千问
 */

(function() {
  'use strict';

  // 实时缓存：存储当前输入的 prompt 内容
  let currentPromptCache = '';

  // 平台配置（模块化设计，每个平台独立配置）
  const PLATFORM_CONFIGS = {
    'chatgpt': {
      domain: /chatgpt\.com|chat\.openai\.com/,
      model: 'chatgpt',
      // ChatGPT 的输入框选择器（优先使用 #prompt-textarea）
      inputSelectors: [
        '#prompt-textarea',
        'textarea[id*="prompt"]',
        'textarea[placeholder*="Message"]'
      ],
      // ChatGPT 的发送按钮选择器
      sendButtonSelectors: [
        '[data-testid="send-button"]',
        'button[aria-label*="Send"]',
        'button:has(svg[data-icon="paper-plane"])'
      ]
    },
    'qwen': {
      domain: /qianwen\.com|tongyi\.aliyun\.com/,
      model: 'qwen',
      // 通义千问的输入框选择器（优先查找最原生、最深层的 textarea）
      inputSelectors: [
        'textarea[rows]',                    // 有 rows 属性的 textarea（通常是输入框）
        'textarea:not([disabled]):not([readonly])',  // 未禁用且非只读的 textarea
        'textarea[placeholder*="输入"]',
        'textarea[placeholder*="消息"]',
        'textarea[placeholder*="说点什么"]',
        'textarea[placeholder*="请输入"]',
        'textarea[class*="input"]',
        'textarea[class*="textarea"]',
        '.input-area textarea',
        '.input-box textarea',
        'textarea'  // 通用 textarea（降级策略）
      ],
      // 通义千问的发送按钮选择器（优先查找带有特定 svg 图标或 aria-label 的 button）
      sendButtonSelectors: [
        'button[aria-label*="发送"]',
        'button[aria-label*="Send"]',
        'button[title*="发送"]',
        'button[title*="Send"]',
        'button:has(svg[class*="send"])',
        'button:has(svg[class*="Send"])',
        'button[type="submit"]',
        'button[class*="send"]',
        'button[class*="Send"]',
        'button[class*="submit"]',
        '.send-button',
        '.submit-button',
        'button:has(svg)'  // 通用按钮（降级策略）
      ]
    }
  };

  // MutationObserver 实例（用于监听 contenteditable 变化）
  let inputMutationObserver = null;
  
  // 当前绑定的输入框元素
  let currentInputElement = null;
  
  // 是否已成功绑定监听
  let isListenerAttached = false;
  
  // DOM 轮询定时器
  let pollingTimer = null;
  
  // 当前平台配置
  let currentPlatformConfig = null;

  /**
   * 检测当前平台
   */
  function detectPlatform() {
    const hostname = window.location.hostname;
    for (const [platform, config] of Object.entries(PLATFORM_CONFIGS)) {
      if (config.domain.test(hostname)) {
        return platform;
      }
    }
    return null;
  }

  /**
   * 获取当前平台配置
   */
  function getPlatformConfig() {
    if (!currentPlatformConfig) {
      const platform = detectPlatform();
      if (platform) {
        currentPlatformConfig = { platform, ...PLATFORM_CONFIGS[platform] };
      }
    }
    return currentPlatformConfig;
  }

  /**
   * 更新缓存：从输入框读取内容并更新到 currentPromptCache
   * 正确判断元素类型：contenteditable 使用 innerText，textarea 使用 value
   */
  function updateCache(inputElement) {
    if (!inputElement) return;
    
    let text = '';
    
    // 判断元素类型并正确提取文本
    if (inputElement.tagName === 'TEXTAREA') {
      // 标准 textarea，使用 value
      text = inputElement.value?.trim() || '';
    } else if (inputElement.contentEditable === 'true' || inputElement.hasAttribute('contenteditable')) {
      // contenteditable 元素，必须使用 innerText 或 textContent
      text = inputElement.innerText?.trim() || inputElement.textContent?.trim() || '';
    } else {
      // 尝试 value 属性（备用）
      text = inputElement.value?.trim() || '';
    }
    
    currentPromptCache = text;
    
    // 增强日志：打印长度和前10个字符
    const preview = text.length > 0 ? text.substring(0, 10) : '(空)';
    const config = getPlatformConfig();
    const platformName = config ? config.platform : 'unknown';
    console.log(`[Prompt Capture] 缓存已更新 (${platformName}): 长度 ${currentPromptCache.length}, 内容: '${preview}${text.length > 10 ? '...' : ''}'`);
  }

  /**
   * 为输入框绑定实时监听
   * 使用 MutationObserver 监听 DOM 变化（防止编辑器吞掉 input 事件）
   */
  function attachInputListener(inputElement) {
    if (!inputElement) return;
    
    // 如果已经绑定过同一个元素，不再重复绑定
    if (currentInputElement === inputElement && isListenerAttached) {
      return;
    }
    
    // 清理旧的监听器
    if (inputMutationObserver) {
      inputMutationObserver.disconnect();
      inputMutationObserver = null;
    }
    
    if (inputElement.tagName === 'TEXTAREA') {
      // 移除旧的监听器（如果存在）
      inputElement.removeEventListener('input', handleInput);
      // 添加新的监听器
      inputElement.addEventListener('input', handleInput, true);
      const config = getPlatformConfig();
      console.log(`[Prompt Capture] 已绑定 textarea input 事件监听 (${config?.platform || 'unknown'})`);
      
      // 初始化缓存
      updateCache(inputElement);
    } 
    // 对于 contenteditable，使用 MutationObserver（更可靠）
    else if (inputElement.contentEditable === 'true' || inputElement.hasAttribute('contenteditable')) {
      // 创建 MutationObserver 监听 DOM 变化
      inputMutationObserver = new MutationObserver(() => {
        updateCache(inputElement);
      });
      
      // 开始观察：监听所有子节点变化、文本变化、子树变化
      inputMutationObserver.observe(inputElement, {
        childList: true,        // 监听子节点变化
        subtree: true,         // 监听所有后代节点
        characterData: true    // 监听文本节点内容变化
      });
      
      const config = getPlatformConfig();
      console.log(`[Prompt Capture] 已绑定 contenteditable MutationObserver 监听 (${config?.platform || 'unknown'})`);
      
      // 初始化缓存
      updateCache(inputElement);
    }
    
    // 记录当前绑定的元素
    currentInputElement = inputElement;
    isListenerAttached = true;
    
    // 停止 DOM 轮询（已找到并绑定）
    stopPolling();
  }

  /**
   * 处理 input 事件（用于 textarea）
   */
  function handleInput(event) {
    updateCache(event.target);
  }

  /**
   * 查找输入框（基于当前平台配置）
   * 严格复用 ChatGPT 的成功逻辑，只替换选择器
   */
  function findInputElement() {
    const config = getPlatformConfig();
    if (!config) {
      console.warn('[Prompt Capture] 未识别的平台:', window.location.hostname);
      return null;
    }

    // 尝试所有选择器（优先使用精确选择器）
    for (const selector of config.inputSelectors) {
      try {
        const element = document.querySelector(selector);
        if (element) {
          // 检查是否是有效的输入元素
          if (element.tagName === 'TEXTAREA' || 
              element.contentEditable === 'true' || 
              element.hasAttribute('contenteditable')) {
            // 对于通义千问，额外验证元素是否可见且可用
            if (config.platform === 'qwen' && element.tagName === 'TEXTAREA') {
              const style = window.getComputedStyle(element);
              if (style.display === 'none' || style.visibility === 'hidden' || element.disabled) {
                continue; // 跳过隐藏或禁用的元素
              }
            }
            console.log(`[Prompt Capture] 找到输入框 (${config.platform}):`, selector);
            return element;
          }
        }
      } catch (e) {
        continue;
      }
    }
    
    // 如果所有选择器都失败，尝试通用查找（降级策略）
    console.log(`[Prompt Capture] 尝试通用查找输入框 (${config.platform})...`);
    
    // 对于通义千问，使用更智能的通用查找
    if (config.platform === 'qwen') {
      // 查找所有可见且可用的 textarea
      const allTextareas = Array.from(document.querySelectorAll('textarea'))
        .filter(textarea => {
          const style = window.getComputedStyle(textarea);
          return style.display !== 'none' && 
                 style.visibility !== 'hidden' && 
                 !textarea.disabled &&
                 !textarea.readOnly &&
                 textarea.offsetWidth > 0 &&
                 textarea.offsetHeight > 0;
        });
      
      if (allTextareas.length > 0) {
        // 选择最大的 textarea（通常是主输入框）
        const largestTextarea = allTextareas.reduce((largest, current) => {
          const currentSize = current.offsetWidth * current.offsetHeight;
          const largestSize = largest.offsetWidth * largest.offsetHeight;
          return currentSize > largestSize ? current : largest;
        });
        console.log(`[Prompt Capture] 使用智能 textarea 选择器 (${config.platform})，找到 ${allTextareas.length} 个候选`);
        return largestTextarea;
      }
    } else {
      // ChatGPT 等其他平台使用原有策略
      const allTextareas = document.querySelectorAll('textarea');
      if (allTextareas.length > 0) {
        const lastTextarea = allTextareas[allTextareas.length - 1];
        console.log(`[Prompt Capture] 使用通用 textarea 选择器 (${config.platform})`);
        return lastTextarea;
      }
    }
    
    // 查找 contenteditable div
    const contentEditables = document.querySelectorAll('[contenteditable="true"]');
    if (contentEditables.length > 0) {
      const lastEditable = contentEditables[contentEditables.length - 1];
      console.log(`[Prompt Capture] 使用通用 contenteditable 选择器 (${config.platform})`);
      return lastEditable;
    }
    
    console.warn(`[Prompt Capture] 未找到输入框 (${config.platform})`);
    return null;
  }

  /**
   * 启动 DOM 轮询：持续寻找输入框
   */
  function startPolling() {
    // 如果已经在轮询，不重复启动
    if (pollingTimer) return;
    
    const config = getPlatformConfig();
    console.log(`[Prompt Capture] 启动 DOM 轮询 (${config?.platform || 'unknown'})，每 500ms 查找一次输入框...`);
    
    pollingTimer = setInterval(() => {
      // 如果已经绑定成功，停止轮询
      if (isListenerAttached && currentInputElement) {
        stopPolling();
        return;
      }
      
      // 尝试查找输入框
      const inputElement = findInputElement();
      if (inputElement) {
        console.log(`[Prompt Capture] 轮询找到输入框，开始绑定监听...`);
        attachInputListener(inputElement);
      }
    }, 500);
    
    // 30 秒后自动停止轮询（避免无限运行）
    setTimeout(() => {
      if (pollingTimer) {
        console.warn(`[Prompt Capture] DOM 轮询超时，停止查找`);
        stopPolling();
      }
    }, 30000);
  }

  /**
   * 停止 DOM 轮询
   */
  function stopPolling() {
    if (pollingTimer) {
      clearInterval(pollingTimer);
      pollingTimer = null;
      console.log('[Prompt Capture] DOM 轮询已停止');
    }
  }

  /**
   * 查找发送按钮（基于当前平台配置）
   */
  function findSendButton(target) {
    const config = getPlatformConfig();
    if (!config) return null;

    // 如果目标元素本身就是按钮，检查是否符合
    if (target.tagName === 'BUTTON' || target.closest('button')) {
      const button = target.tagName === 'BUTTON' ? target : target.closest('button');
      // 检查按钮是否包含发送相关的文本或图标
      const buttonText = button.textContent?.toLowerCase() || '';
      const ariaLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
      if (buttonText.includes('send') || buttonText.includes('发送') || 
          ariaLabel.includes('send') || ariaLabel.includes('发送')) {
        return button;
      }
    }

    // 尝试所有选择器
    for (const selector of config.sendButtonSelectors) {
      try {
        const element = document.querySelector(selector);
        if (element) {
          console.log(`[Prompt Capture] 找到发送按钮 (${config.platform}):`, selector);
          return element;
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  // 使用事件代理在 document 级别进行监听
  document.addEventListener('keydown', handleKeyDown, true);
  document.addEventListener('click', handleClick, true);

  /**
   * 处理键盘按下事件（触发条件 A）
   */
  function handleKeyDown(event) {
    const target = event.target;
    
    // 检查是否是 textarea 或 contenteditable
    const isTextInput = target.tagName === 'TEXTAREA' || 
                       target.contentEditable === 'true' || 
                       target.hasAttribute('contenteditable');
    
    if (isTextInput) {
      // 验证是否是目标输入框
      if (currentInputElement && (target === currentInputElement || currentInputElement.contains(target))) {
        // 如果按下的是 Enter 键且没有按 Shift 键，则触发提取
        if (event.key === 'Enter' && !event.shiftKey) {
          const config = getPlatformConfig();
          console.log(`[Prompt Capture] 检测到 Enter 键 (${config?.platform || 'unknown'})，准备提取...`);
          // 直接从缓存读取，不延迟
          extractAndSendPrompt();
        }
      }
    }
  }

  /**
   * 处理点击事件（触发条件 B）
   */
  function handleClick(event) {
    const target = event.target;
    const sendButton = findSendButton(target);
    
    if (sendButton) {
      const config = getPlatformConfig();
      console.log(`[Prompt Capture] 检测到发送按钮点击 (${config?.platform || 'unknown'})，准备提取...`);
      // 直接从缓存读取，不延迟
      extractAndSendPrompt();
    }
  }

  /**
   * 提取 prompt 并发送给后台脚本
   * 直接从缓存读取，不从 DOM 读取
   */
  function extractAndSendPrompt() {
    const config = getPlatformConfig();
    if (!config) {
      console.error('[Prompt Capture] 无法识别平台，跳过捕获');
      return;
    }

    // 从缓存读取 prompt 文本
    const promptText = currentPromptCache.trim();
    
    console.log(`[Prompt Capture] 从缓存提取 (${config.platform})，文本长度:`, promptText.length);
    
    // 如果是空字符则直接 return 忽略
    if (!promptText) {
      console.warn(`[Prompt Capture] 缓存为空 (${config.platform})，跳过捕获`);
      return;
    }

    // 构造数据对象
    const dataObject = {
      id: crypto.randomUUID(),
      prompt: promptText,
      model: config.model,
      url: window.location.href,
      ts: Date.now()
    };

    // 控制台调试输出
    console.log(`[Prompt Capture] 已捕获 Prompt (${config.platform}):`, dataObject);

    // 使用 chrome.runtime.sendMessage 将数据发给后台脚本
    chrome.runtime.sendMessage({
      type: 'SAVE_PROMPT',
      data: dataObject
    }, (response) => {
      // 处理后台脚本的响应
      if (chrome.runtime.lastError) {
        console.error(`[Prompt Capture] 发送消息失败 (${config.platform}):`, chrome.runtime.lastError.message);
        return;
      }
      
      if (response && response.success) {
        console.log(`✅ [Prompt Capture] Prompt 保存成功 (${config.platform}):`, response);
      } else {
        console.error(`❌ [Prompt Capture] Prompt 保存失败 (${config.platform}):`, response?.error || '未知错误');
      }
    });

    // 发送成功后，立即清空缓存
    currentPromptCache = '';
    console.log(`[Prompt Capture] 缓存已清空 (${config.platform})`);
  }

  /**
   * 初始化：查找输入框并绑定监听
   */
  function init() {
    const config = getPlatformConfig();
    if (!config) {
      console.warn('[Prompt Capture] 未识别的平台:', window.location.hostname);
      return;
    }
    
    console.log(`[Prompt Capture] 开始初始化，当前平台: ${config.platform}`);
    
    // 立即尝试查找一次
    const inputElement = findInputElement();
    if (inputElement) {
      console.log(`[Prompt Capture] 初始查找成功 (${config.platform})，绑定监听...`);
      attachInputListener(inputElement);
    } else {
      console.log(`[Prompt Capture] 初始查找失败 (${config.platform})，启动 DOM 轮询...`);
      // 启动轮询持续查找
      startPolling();
      
      // 同时使用全局 MutationObserver 作为备用方案
      const globalObserver = new MutationObserver(() => {
        // 如果还没绑定，尝试查找
        if (!isListenerAttached) {
          const inputElement = findInputElement();
          if (inputElement) {
            console.log(`[Prompt Capture] MutationObserver 发现输入框 (${config.platform})，绑定监听...`);
            attachInputListener(inputElement);
            globalObserver.disconnect();
          }
        }
      });
      
      globalObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
      
      // 30 秒后停止观察
      setTimeout(() => {
        globalObserver.disconnect();
      }, 30000);
    }
  }

  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    // DOM 已加载，直接初始化
    init();
  }
})();
